<?php
/*
Plugin Name: Plugin Base
Description: Base para cria��o do seu plugin!
Author: Heberton Eduardo
Version: 1.0.0
 * Text domain: plugin_basico
*/    
// Include mfp-functions.php, use require_once to stop the script if mfp-functions.php is not found
require_once plugin_dir_path(__FILE__) . 'includes/cm-functions.php';

if(!function_exists('add_action')){
    echo __('O plugin não pode ser passado diretamente', 'plugin_basico');
exit;    }
   
register_activation_hook(__FILE__, 'hc_activate');
 include ('includes/activate.php');