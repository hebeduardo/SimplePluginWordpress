<?php
//Verifica��o versão do Wordpress < 4.5
function hc_activate(){
    // 4.5 <4.4
    if (version_compare(get_bloginfo('version'), '4.5', '<')){
        wp_die(__('Você precisa atualizar o wordpress para utilizar o plugin', 'classic_motoring'));
}}
