<?php
/*
 * adiciona link no menu administrativo do wordpress
 */
 // Hook o 'admin_menu' action hook, roda a fun��o de nome 'cm_Add_My_Admin_Link()'
add_action( 'admin_menu', 'cm_Add_My_Admin_Link' );
// Add um menu no painel administrativo do wordpress

function cm_Add_My_Admin_Link()
{
  add_menu_page(
        'Classic Motoring', // T�tulo d ap�gina
        'Classic Motoring', // Texto do Menu
        'manage_options', // Requisito de capacidade para ver o link
        'nome-da-pagina-1', 
        'pagina1'); 
  //Fun��o para abrir a p�gina do plugin
  function pagina1() { 
       require_once "cm-first-acp-page.php"; }
}
