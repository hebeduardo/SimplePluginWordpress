<div class="wrap">
  <h1>Plugin B�sico</h1>
  <hr/>
  <p>P�gina para o Plugin</p>
</div>

